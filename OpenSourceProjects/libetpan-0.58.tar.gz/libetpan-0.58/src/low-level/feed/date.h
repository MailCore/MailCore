#ifndef DATE_H
#define DATE_H

#include <time.h>

time_t newsfeed_iso8601_date_parse(char *date);

#endif /* __DATE_H */
