#ifndef TIMEUTILS_H

#define TIMEUTILS_H

#include <time.h>

time_t mail_mkgmtime(struct tm * tmp);

#endif
