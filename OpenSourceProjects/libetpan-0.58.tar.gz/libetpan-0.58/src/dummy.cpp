/* We need to link the W32 version of the library using the C++ tool
   chain.  This file ensures that this happens.  */
